jQuery(document).ready(function($) {
    // Handle Start Bot button click
    $('#ton-start-bot').on('click', function() {
        var $button = $(this);
        $button.prop('disabled', true).text('Starting bot...');

        // Open Telegram bot in new window
        window.open('http://t.me/WoocommerceOrder_bot', '_blank');

        // Start polling for updates
        pollForUpdates();
    });

    // Handle Test Notification button click
    $('#ton-test-notification').on('click', function() {
        var $button = $(this);
        $button.prop('disabled', true).text('Sending...');

        $.ajax({
            url: tonAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'ton_send_test_notification',
                nonce: tonAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert('Test notification sent successfully!');
                } else {
                    alert('Failed to send test notification: ' + response.data);
                }
            },
            error: function() {
                alert('Failed to send test notification. Please try again.');
            },
            complete: function() {
                $button.prop('disabled', false).text('Send Test Notification');
            }
        });
    });

    // Poll for updates from Telegram
    function pollForUpdates() {
        $.ajax({
            url: tonAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'ton_check_telegram_updates',
                nonce: tonAdmin.nonce
            },
            success: function(response) {
                if (response.success && response.data.chat_id) {
                    // Update chat ID field
                    $('#ton_chat_id').val(response.data.chat_id);
                    
                    // Show success message
                    alert('Chat ID detected successfully! Please save your settings.');
                    
                    // Stop polling
                    return;
                }
                
                // Continue polling if no chat ID detected
                setTimeout(pollForUpdates, 5000);
            },
            error: function() {
                // Stop polling on error
                $('#ton-start-bot').prop('disabled', false).text('Start Telegram Bot');
            }
        });
    }

    // Handle form submission
    $('#ton-settings-form').on('submit', function(e) {
        var chatId = $('#ton_chat_id').val();
        if (!chatId) {
            e.preventDefault();
            alert('Please complete the Telegram bot setup first.');
            return false;
        }
    });

    // Add smooth scrolling to steps
    $('.ton-step').each(function(index) {
        $(this).addClass('ton-step-' + (index + 1));
    });
}); 