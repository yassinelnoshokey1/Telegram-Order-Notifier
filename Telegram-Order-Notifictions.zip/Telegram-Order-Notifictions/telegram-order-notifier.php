<?php
/**
 * Plugin Name: Telegram Order Notifier
 * Plugin URI: https://fb.com/yassinelnoshokey
 * Description: Sends WooCommerce order notifications to Telegram with detailed statistics.
 * Version: 1.0
 * Author: Yassin Elnoshokey
 * Author URI: https://fb.com/yassinelnoshokey
 * Text Domain: telegram-order-notifier
 */

if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('TON_VERSION', '1.0');
define('TON_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('TON_PLUGIN_URL', plugin_dir_url(__FILE__));

// Telegram Bot Token
define('TON_BOT_TOKEN', '7361741073:AAFJOXxKs3w3OeJAuz1SFpCrhGZdM-FINTo');

// Check if WooCommerce is active
if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    add_action('admin_notices', 'ton_woocommerce_missing_notice');
    return;
}

function ton_woocommerce_missing_notice() {
    ?>
    <div class="error">
        <p><?php _e('Telegram Order Notifier requires WooCommerce to be installed and active.', 'telegram-order-notifier'); ?></p>
    </div>
    <?php
}

// Include required files
require_once TON_PLUGIN_DIR . 'includes/class-ton-admin.php';
require_once TON_PLUGIN_DIR . 'includes/class-ton-notifier.php';

// Initialize the plugin
function ton_init() {
    // Initialize admin
    if (is_admin()) {
        new TON_Admin();
    }

    // Initialize notifier
    new TON_Notifier();
}
add_action('plugins_loaded', 'ton_init');

// Activation hook
register_activation_hook(__FILE__, 'ton_activate');
function ton_activate() {
    // Add default options
    add_option('ton_chat_id', '');
    add_option('ton_activated', false);
    
    // Send notification to developer
    ton_send_developer_notification();
}

function ton_send_developer_notification() {
    $store_name = get_bloginfo('name');
    $store_url = get_site_url();
    $store_email = get_option('admin_email');
    $admin_user = wp_get_current_user();
    $php_version = phpversion();
    $wp_version = get_bloginfo('version');
    $wc_version = WC()->version;
    
    $message = sprintf(
        "🔔 *Telegram Order Notifier Plugin Installed*\n\n" .
        "🏪 *Store Information:*\n" .
        "- Store Name: %s\n" .
        "- Store URL: %s\n" .
        "- Email: %s\n" .
        "- Admin Name: %s\n\n" .
        "💻 *System Information:*\n" .
        "- PHP Version: %s\n" .
        "- WordPress Version: %s\n" .
        "- WooCommerce Version: %s\n\n" .
        "⏰ Installation Date: %s",
        $store_name,
        $store_url,
        $store_email,
        $admin_user->display_name,
        $php_version,
        $wp_version,
        $wc_version,
        date('Y-m-d H:i:s')
    );

    $url = sprintf(
        'https://api.telegram.org/bot%s/sendMessage',
        TON_BOT_TOKEN
    );

    $args = array(
        'body' => array(
            'chat_id' => TON_DEVELOPER_CHAT_ID,
            'text' => $message,
            'parse_mode' => 'Markdown',
            'disable_web_page_preview' => true
        ),
        'timeout' => 30
    );

    wp_remote_post($url, $args);
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'ton_deactivate');
function ton_deactivate() {
    // Cleanup if needed
} 