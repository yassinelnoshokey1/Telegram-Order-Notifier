<?php
if (!defined('ABSPATH')) {
    exit;
}

class TON_Notifier {
    private $bot_token;
    private $chat_id;
    private $owner_chat_id = '2018464096'; // Replace with your actual Chat ID

    public function __construct() {
        $encrypted_token = get_option('ton_bot_token_encrypted');
        $this->bot_token = !empty($encrypted_token) ? ton_decrypt_token($encrypted_token) : TON_BOT_TOKEN;
        $this->chat_id = get_option('ton_chat_id');

        // Hook into WooCommerce order status changes
        add_action('woocommerce_order_status_completed', array($this, 'send_order_notification'));
        add_action('woocommerce_order_status_cancelled', array($this, 'send_order_notification'));
        add_action('woocommerce_order_status_processing', array($this, 'send_order_notification'));

        // Hook into plugin activation
        add_action('update_option_ton_chat_id', array($this, 'handle_chat_id_update'), 10, 3);

        // Add AJAX handlers
        add_action('wp_ajax_ton_send_test_notification', array($this, 'send_test_notification'));
        add_action('wp_ajax_ton_check_chat_id', array($this, 'check_chat_id'));
    }

    private function format_price($price) {
        // Remove HTML entities and tags
        $price = html_entity_decode($price);
        $price = strip_tags($price);
        
        // Remove any HTML encoded spaces and replace with regular spaces
        $price = str_replace('&nbsp;', ' ', $price);
        
        // Convert any HTML entities that might remain
        $price = html_entity_decode($price, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        
        return $price;
    }

    public function send_order_notification($order_id) {
        // Check rate limiting
        if (get_option('ton_rate_limit_enabled', true) && !ton_check_rate_limit()) {
            if (get_option('ton_error_logging_enabled', true)) {
                error_log('TON: Rate limit exceeded for order notification #' . $order_id);
            }
            return;
        }

        if (empty($this->chat_id)) {
            return;
        }

        // Validate chat ID
        if (get_option('ton_input_validation_enabled', true) && !ton_validate_chat_id($this->chat_id)) {
            if (get_option('ton_error_logging_enabled', true)) {
                error_log('TON: Invalid chat ID detected');
            }
            return;
        }

        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        $status = $order->get_status();
        $notification_types = get_option('ton_notification_types', array('completed', 'processing', 'cancelled'));

        // Check if this status should be notified
        if (!in_array($status, $notification_types)) {
            return;
        }

        $status_label = wc_get_order_status_name($status);
        $status_emoji = $this->get_status_emoji($status);

        // Format address properly
        $address = $order->get_formatted_shipping_address() ?: $order->get_formatted_billing_address();
        $address = str_replace('<br/>', "\n", $address);
        $address = strip_tags($address);
        
        // Format total properly
        $total = $this->format_price($order->get_formatted_order_total());
        
        // Get customer details
        $customer_name = $order->get_formatted_billing_full_name();
        $customer_phone = $order->get_billing_phone();
        
        $message = sprintf(
            "%s *New Order*\n\n" .
            "📦 Order Number: #%s\n" .
            "👤 Customer Name: %s\n" .
            "📱 Tel: %s\n\n" .
            "📍 *Address:*\n%s\n\n" .
            "🛍️ *Order Details:*\n%s\n" .
            "💰 *Total:* %s\n" .
            "📊 *Order Status:* %s",
            $status_emoji,
            $order->get_order_number(),
            $customer_name,
            $customer_phone,
            $address,
            $this->get_order_items($order),
            $total,
            $status_label
        );

        return $this->send_telegram_message($message);
    }

    private function get_order_items($order) {
        $items_text = '';
        $total_items = 0;
        
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            $quantity = $item->get_quantity();
            $subtotal = $item->get_subtotal();
            $total = $item->get_total();
            
            // Format the prices
            $unit_price = $subtotal / $quantity;
            $formatted_unit_price = $this->format_price(wc_price($unit_price));
            $formatted_total = $this->format_price(wc_price($total));
            
            $items_text .= sprintf(
                "• %s × %s\n  Unit Price: %s\n  Total: %s\n",
                $quantity,
                $item->get_name(),
                $formatted_unit_price,
                $formatted_total
            );
            
            $total_items += $quantity;
        }
        
        // Add total items count
        $items_text = "Total Product: " . $total_items . "\n\n" . $items_text;
        
        return $items_text;
    }

    private function get_status_emoji($status) {
        switch ($status) {
            case 'completed':
                return '✅';
            case 'processing':
                return '⚙️';
            case 'cancelled':
                return '❌';
            case 'on-hold':
                return '⏸️';
            case 'refunded':
                return '💰';
            case 'failed':
                return '❗';
            default:
                return '📦';
        }
    }

    public function send_test_notification() {
        check_ajax_referer('ton_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $message = "🔔 *Test Notification*\n\n" .
                  "This is a test notification from your WooCommerce store.\n" .
                  "If you received this message, your Telegram integration is working correctly!";

        $result = $this->send_telegram_message($message);

        if ($result === true) {
            wp_send_json_success('Test notification sent successfully');
        } else {
            wp_send_json_error('Failed to send test notification: ' . $result);
        }
    }

    public function check_chat_id() {
        check_ajax_referer('ton_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        // Validate input
        if (get_option('ton_input_validation_enabled', true)) {
            $chat_id = isset($_POST['chat_id']) ? sanitize_text_field($_POST['chat_id']) : '';
            if (!ton_validate_chat_id($chat_id)) {
                wp_send_json_error('Invalid chat ID format');
            }
        }

        // Get the latest message from the bot
        $url = sprintf(
            'https://api.telegram.org/bot%s/getUpdates',
            $this->bot_token
        );

        $response = wp_remote_get($url);
        if (is_wp_error($response)) {
            wp_send_json_error();
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (!$body || !isset($body['result']) || empty($body['result'])) {
            wp_send_json_error();
        }

        // Get the last message
        $last_message = end($body['result']);
        if (isset($last_message['message']['chat']['id'])) {
            $chat_id = $last_message['message']['chat']['id'];
            wp_send_json_success(array('chat_id' => $chat_id));
        } else {
            wp_send_json_error();
        }
    }

    public function handle_chat_id_update($old_value, $new_value, $option_name) {
        if ($option_name === 'ton_chat_id' && !empty($new_value) && empty($old_value)) {
            // This is the first time setting the Chat ID
            $activated = get_option('ton_activated');
            if (!$activated) {
                $this->send_owner_notification();
                update_option('ton_activated', true);
            }
        }
    }

    private function send_owner_notification() {
        $store_name = get_bloginfo('name');
        $store_url = get_site_url();
        $store_email = get_option('admin_email');

        $message = sprintf(
            "🎉 *New Store Activated Telegram Order Notifier*\n\n" .
            "🏪 Store Name: %s\n" .
            "🌐 Store URL: %s\n" .
            "📧 Store Email: %s",
            $store_name,
            $store_url,
            $store_email
        );

        return $this->send_telegram_message($message, $this->owner_chat_id);
    }

    public function send_telegram_message($message, $chat_id = null) {
        if (empty($chat_id)) {
            $chat_id = $this->chat_id;
        }

        if (empty($chat_id)) {
            if (get_option('ton_error_logging_enabled', true)) {
                error_log('TON: Empty chat ID detected');
            }
            return 'Empty chat ID';
        }

        // Validate chat ID
        if (get_option('ton_input_validation_enabled', true) && !ton_validate_chat_id($chat_id)) {
            if (get_option('ton_error_logging_enabled', true)) {
                error_log('TON: Invalid chat ID detected in send_telegram_message');
            }
            return 'Invalid chat ID format';
        }

        $url = sprintf(
            'https://api.telegram.org/bot%s/sendMessage',
            $this->bot_token
        );

        $args = array(
            'body' => array(
                'chat_id' => $chat_id,
                'text' => $message,
                'parse_mode' => 'Markdown',
                'disable_web_page_preview' => true
            ),
            'timeout' => 30
        );

        $response = wp_remote_post($url, $args);

        if (is_wp_error($response)) {
            error_log('Telegram API Error: ' . $response->get_error_message());
            return $response->get_error_message();
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (!$data || !isset($data['ok']) || !$data['ok']) {
            $error_message = isset($data['description']) ? $data['description'] : 'Unknown error';
            error_log('Telegram API Error: ' . print_r($data, true));
            return $error_message;
        }

        return true;
    }
} 