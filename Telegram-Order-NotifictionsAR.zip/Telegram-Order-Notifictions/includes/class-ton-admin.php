<?php
if (!defined('ABSPATH')) {
    exit;
}

class TON_Admin {
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_notices', array($this, 'check_telegram_connection'));
        add_action('activated_plugin', array($this, 'activation_redirect'));

        // Add AJAX handlers
        add_action('wp_ajax_ton_check_telegram_updates', array($this, 'check_telegram_updates'));
        add_action('wp_ajax_ton_send_test_notification', array($this, 'send_test_notification'));
    }

    public function add_admin_menu() {
        // Add main menu item
        add_menu_page(
            __('Telegram Notifier', 'telegram-order-notifier'),
            __('Telegram Notifier', 'telegram-order-notifier'),
            'manage_options',
            'telegram-notifier',
            array($this, 'render_settings_page'),
            TON_PLUGIN_URL . 'assets/images/logo.png',
            56
        );

        // Add submenu items
        add_submenu_page(
            'telegram-notifier',
            __('Settings', 'telegram-order-notifier'),
            __('Settings', 'telegram-order-notifier'),
            'manage_options',
            'telegram-notifier',
            array($this, 'render_settings_page')
        );

        add_submenu_page(
            'telegram-notifier',
            __('Statistics', 'telegram-order-notifier'),
            __('Statistics', 'telegram-order-notifier'),
            'manage_options',
            'telegram-statistics',
            array($this, 'render_statistics_page')
        );
    }

    public function check_telegram_connection() {
        $chat_id = get_option('ton_chat_id');
        if (empty($chat_id)) {
            ?>
            <div class="notice notice-warning is-dismissible">
                <p><?php _e('Telegram Order Notifier: Please complete the setup to start receiving order notifications.', 'telegram-order-notifier'); ?></p>
            </div>
            <?php
        }
    }

    public function enqueue_admin_assets($hook) {
        if (strpos($hook, 'telegram-notifier') === false && strpos($hook, 'telegram-statistics') === false) {
            return;
        }

        // Add minimal icon styling
        $custom_admin_css = "
            #adminmenu .toplevel_page_telegram-notifier img {
                width: 20px;
                height: 20px;
                padding-top: 7px;
            }
        ";
        wp_add_inline_style('admin-menu', $custom_admin_css);

        wp_enqueue_style(
            'ton-admin-styles',
            TON_PLUGIN_URL . 'assets/css/styles.css',
            array(),
            TON_VERSION
        );

        wp_enqueue_script(
            'ton-admin-script',
            TON_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery'),
            TON_VERSION,
            true
        );

        wp_localize_script('ton-admin-script', 'tonAdmin', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ton_admin_nonce')
        ));
    }

    public function register_settings() {
        register_setting('ton_settings', 'ton_chat_id');
        register_setting('ton_settings', 'ton_notification_types', array(
            'type' => 'array',
            'default' => array('completed', 'processing', 'cancelled'),
            'sanitize_callback' => array($this, 'sanitize_notification_types')
        ));
    }

    public function sanitize_notification_types($input) {
        if (!is_array($input)) {
            return array('completed', 'processing', 'cancelled');
        }
        return array_intersect($input, array('completed', 'processing', 'cancelled'));
    }

    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $chat_id = get_option('ton_chat_id');
        $notification_types = get_option('ton_notification_types', array('completed', 'processing', 'cancelled'));
        
        if (!is_array($notification_types)) {
            $notification_types = array('completed', 'processing', 'cancelled');
        }
        ?>
        <div class="wrap">
            <div class="ton-container">
                <div class="ton-header">
                    <h1><?php _e('Telegram Order Notifier Settings', 'telegram-order-notifier'); ?></h1>
                </div>

                <div class="ton-video-guide">
                    <h2><?php _e('شاهد الفيديو التوضيحي', 'telegram-order-notifier'); ?></h2>
                    <div class="ton-video-container">
                        <iframe width="100%" height="400" src="https://www.youtube.com/embed/YOUR_VIDEO_ID" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                    <p class="ton-video-description"><?php _e('شاهد كيفية إعداد وتفعيل إشعارات تيليجرام لمتجرك في خطوات بسيطة', 'telegram-order-notifier'); ?></p>
                </div>

                <div class="ton-setup-steps">
                    <div class="ton-step">
                        <div class="ton-step-number">1</div>
                        <div class="ton-step-content">
                            <h3><?php _e('Click the button below to start the Telegram bot', 'telegram-order-notifier'); ?></h3>
                            <button type="button" class="button button-primary" id="ton-start-bot">
                                <?php _e('Start Telegram Bot', 'telegram-order-notifier'); ?>
                            </button>
                        </div>
                    </div>

                    <div class="ton-step">
                        <div class="ton-step-number">2</div>
                        <div class="ton-step-content">
                            <h3><?php _e('Send /start to the bot', 'telegram-order-notifier'); ?></h3>
                            <p><?php _e('Open Telegram and send /start to the bot. The Chat ID will be automatically detected.', 'telegram-order-notifier'); ?></p>
                        </div>
                    </div>

                    <div class="ton-step">
                        <div class="ton-step-number">3</div>
                        <div class="ton-step-content">
                            <h3><?php _e('Select notification types', 'telegram-order-notifier'); ?></h3>
                            <div class="ton-checkbox-group">
                                <label>
                                    <input type="checkbox" name="ton_notification_types[]" value="completed" <?php checked(in_array('completed', $notification_types)); ?>>
                                    <?php _e('Completed Orders', 'telegram-order-notifier'); ?>
                                </label>
                                <label>
                                    <input type="checkbox" name="ton_notification_types[]" value="processing" <?php checked(in_array('processing', $notification_types)); ?>>
                                    <?php _e('Processing Orders', 'telegram-order-notifier'); ?>
                                </label>
                                <label>
                                    <input type="checkbox" name="ton_notification_types[]" value="cancelled" <?php checked(in_array('cancelled', $notification_types)); ?>>
                                    <?php _e('Cancelled Orders', 'telegram-order-notifier'); ?>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                <form method="post" action="options.php" id="ton-settings-form">
                    <?php
                    settings_fields('ton_settings');
                    ?>
                    <input type="hidden" name="ton_chat_id" id="ton_chat_id" value="<?php echo esc_attr($chat_id); ?>">
                    
                    <div class="ton-form-group">
                        <?php submit_button(__('Save Settings', 'telegram-order-notifier'), 'primary ton-submit-button'); ?>
                    </div>
                </form>

                <div class="ton-test-notification">
                    <h3><?php _e('Test Notification', 'telegram-order-notifier'); ?></h3>
                    <p><?php _e('Click the button below to send a test notification to your Telegram:', 'telegram-order-notifier'); ?></p>
                    <button type="button" class="button button-secondary" id="ton-test-notification">
                        <?php _e('Send Test Notification', 'telegram-order-notifier'); ?>
                    </button>
                </div>
            </div>
        </div>

        <style>
        .ton-video-guide {
            background: #fff;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            text-align: center;
        }

        .ton-video-guide h2 {
            color: #333;
            margin-bottom: 20px;
            font-size: 24px;
        }

        .ton-video-container {
            position: relative;
            padding-bottom: 56.25%;
            height: 0;
            overflow: hidden;
            max-width: 100%;
            margin-bottom: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .ton-video-container iframe {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border-radius: 8px;
        }

        .ton-video-description {
            color: #666;
            font-size: 16px;
            margin-top: 15px;
        }
        </style>
        <?php
    }

    public function render_statistics_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        // Get current month and year
        $current_month = date('m');
        $current_year = date('Y');
        $days_in_month = date('t');

        // Get WooCommerce statistics
        $completed_orders = wc_get_orders(array(
            'status' => 'completed',
            'return' => 'ids',
            'date_created' => '>=' . $current_year . '-' . $current_month . '-01'
        ));

        $cancelled_orders = wc_get_orders(array(
            'status' => 'cancelled',
            'return' => 'ids',
            'date_created' => '>=' . $current_year . '-' . $current_month . '-01'
        ));

        $processing_orders = wc_get_orders(array(
            'status' => 'processing',
            'return' => 'ids'
        ));

        // Calculate total sales for current month
        $monthly_sales = 0;
        $daily_average = 0;
        $orders = wc_get_orders(array(
            'status' => 'completed',
            'date_created' => '>=' . $current_year . '-' . $current_month . '-01',
            'date_created' => '<=' . $current_year . '-' . $current_month . '-' . $days_in_month,
        ));

        foreach ($orders as $order) {
            $monthly_sales += $order->get_total();
        }

        // Calculate daily average
        $days_passed = min((int)date('d'), $days_in_month);
        $daily_average = $monthly_sales > 0 ? $monthly_sales / $days_passed : 0;

        // Get total products sold this month
        $total_products = 0;
        foreach ($orders as $order) {
            $items = $order->get_items();
            foreach ($items as $item) {
                $total_products += $item->get_quantity();
            }
        }

        ?>
        <div class="wrap">
            <div class="ton-container">
                <div class="ton-header">
                    <h1><?php _e('إحصائيات المتجر', 'telegram-order-notifier'); ?></h1>
                    <p class="description"><?php echo sprintf(__('إحصائيات شهر %s %s', 'telegram-order-notifier'), date_i18n('F'), date('Y')); ?></p>
                </div>

                <div class="ton-stats-overview">
                    <!-- Row 1: Main Financial Stats -->
                    <div class="ton-stats-row main-stats">
                        <div class="ton-stat-card ton-stat-sales">
                            <div class="ton-stat-icon">💰</div>
                            <div class="ton-stat-content">
                                <div class="ton-stat-value"><?php echo wc_price($monthly_sales); ?></div>
                                <div class="ton-stat-label"><?php _e('إجمالي المبيعات', 'telegram-order-notifier'); ?></div>
                                <div class="ton-stat-sublabel"><?php echo sprintf(__('المتوسط اليومي: %s', 'telegram-order-notifier'), wc_price($daily_average)); ?></div>
                            </div>
                        </div>

                        <div class="ton-stat-card ton-stat-conversion">
                            <div class="ton-stat-icon">📊</div>
                            <div class="ton-stat-content">
                                <div class="ton-stat-value"><?php 
                                    $avg_order_value = $completed_orders ? round($monthly_sales / count($completed_orders), 2) : 0;
                                    echo wc_price($avg_order_value); 
                                ?></div>
                                <div class="ton-stat-label"><?php _e('متوسط قيمة الطلب', 'telegram-order-notifier'); ?></div>
                            </div>
                        </div>
                    </div>

                    <!-- Row 2: Order Status Stats -->
                    <div class="ton-stats-row order-stats">
                        <div class="ton-stat-card ton-stat-orders">
                            <div class="ton-stat-icon">📦</div>
                            <div class="ton-stat-content">
                                <div class="ton-stat-value"><?php echo count($completed_orders); ?></div>
                                <div class="ton-stat-label"><?php _e('الطلبات المكتملة', 'telegram-order-notifier'); ?></div>
                                <div class="ton-stat-sublabel"><?php echo sprintf(__('نسبة النجاح: %s%%', 'telegram-order-notifier'), 
                                    $completed_orders ? round((count($completed_orders) / (count($completed_orders) + count($cancelled_orders))) * 100) : 0
                                ); ?></div>
                            </div>
                        </div>

                        <div class="ton-stat-card ton-stat-processing">
                            <div class="ton-stat-icon">⚙️</div>
                            <div class="ton-stat-content">
                                <div class="ton-stat-value"><?php echo count($processing_orders); ?></div>
                                <div class="ton-stat-label"><?php _e('طلبات قيد المعالجة', 'telegram-order-notifier'); ?></div>
                            </div>
                        </div>

                        <div class="ton-stat-card ton-stat-cancelled">
                            <div class="ton-stat-icon">❌</div>
                            <div class="ton-stat-content">
                                <div class="ton-stat-value"><?php echo count($cancelled_orders); ?></div>
                                <div class="ton-stat-label"><?php _e('الطلبات الملغاة', 'telegram-order-notifier'); ?></div>
                            </div>
                        </div>
                    </div>

                    <!-- Row 3: Products Stats -->
                    <div class="ton-stats-row products-stats">
                        <div class="ton-stat-card ton-stat-products">
                            <div class="ton-stat-icon">🛍️</div>
                            <div class="ton-stat-content">
                                <div class="ton-stat-value"><?php echo $total_products; ?></div>
                                <div class="ton-stat-label"><?php _e('المنتجات المباعة', 'telegram-order-notifier'); ?></div>
                                <div class="ton-stat-sublabel"><?php echo sprintf(__('متوسط المنتجات لكل طلب: %s', 'telegram-order-notifier'), 
                                    $completed_orders ? round($total_products / count($completed_orders), 1) : 0
                                ); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <style>
        .ton-stats-overview {
            margin-top: 30px;
        }

        .ton-stats-row {
            display: grid;
            gap: 20px;
            margin-bottom: 25px;
        }

        .ton-stats-row.main-stats {
            grid-template-columns: 2fr 1fr;
        }

        .ton-stats-row.order-stats {
            grid-template-columns: repeat(3, 1fr);
        }

        .ton-stats-row.products-stats {
            grid-template-columns: 1fr;
            max-width: 600px;
            margin: 0 auto;
        }

        .ton-stat-card {
            background: #fff;
            border-radius: 12px;
            padding: 25px;
            display: flex;
            align-items: flex-start;
            transition: all 0.3s ease;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            border: 1px solid #eee;
        }

        .ton-stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0, 136, 204, 0.1);
        }

        .ton-stat-icon {
            font-size: 24px;
            margin-left: 15px;
            background: #f8f9fa;
            width: 50px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 12px;
        }

        .ton-stat-content {
            flex: 1;
            text-align: right;
        }

        .ton-stat-value {
            font-size: 28px;
            font-weight: bold;
            color: #0088cc;
            margin-bottom: 5px;
        }

        .ton-stat-label {
            color: #333;
            font-size: 16px;
            margin-bottom: 5px;
        }

        .ton-stat-sublabel {
            color: #666;
            font-size: 14px;
        }

        /* Card Colors */
        .ton-stat-sales .ton-stat-icon {
            background: #e3f2fd;
            color: #0088cc;
        }

        .ton-stat-orders .ton-stat-icon {
            background: #e8f5e9;
            color: #4caf50;
        }

        .ton-stat-products .ton-stat-icon {
            background: #fff3e0;
            color: #ff9800;
        }

        .ton-stat-processing .ton-stat-icon {
            background: #ede7f6;
            color: #673ab7;
        }

        .ton-stat-cancelled .ton-stat-icon {
            background: #fce4ec;
            color: #e91e63;
        }

        .ton-stat-conversion .ton-stat-icon {
            background: #e0f2f1;
            color: #009688;
        }

        @media (max-width: 1200px) {
            .ton-stats-row.main-stats,
            .ton-stats-row.order-stats {
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            }
        }
        </style>
        <?php
    }

    public function check_telegram_updates() {
        check_ajax_referer('ton_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $bot_token = TON_BOT_TOKEN;
        $url = "https://api.telegram.org/bot{$bot_token}/getUpdates";

        $response = wp_remote_get($url);

        if (is_wp_error($response)) {
            wp_send_json_error('Failed to connect to Telegram API');
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (!$data || !isset($data['ok']) || !$data['ok']) {
            wp_send_json_error('Invalid response from Telegram API');
        }

        // Get the most recent message
        $updates = $data['result'];
        if (empty($updates)) {
            wp_send_json_error('No updates found');
        }

        $latest_update = end($updates);
        $message = $latest_update['message'];

        // Check if it's a /start command
        if (isset($message['text']) && $message['text'] === '/start') {
            $chat_id = $message['chat']['id'];
            wp_send_json_success(array('chat_id' => $chat_id));
        }

        wp_send_json_error('No /start command found');
    }

    public function send_test_notification() {
        check_ajax_referer('ton_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $chat_id = get_option('ton_chat_id');
        if (empty($chat_id)) {
            wp_send_json_error('Chat ID not set');
        }

        $message = "🔄 *Test Notification*\n\n" .
                  "✅ This is a test notification from your WooCommerce store.\n" .
                  "📦 If you received this message, your Telegram integration is working correctly!";

        $notifier = new TON_Notifier();
        $result = $notifier->send_telegram_message($message);

        if ($result) {
            wp_send_json_success('Test notification sent successfully');
        } else {
            wp_send_json_error('Failed to send test notification');
        }
    }

    public function activation_redirect($plugin) {
        if($plugin == plugin_basename(TON_PLUGIN_FILE)) {
            exit(wp_redirect(admin_url('admin.php?page=telegram-notifier')));
        }
    }
} 